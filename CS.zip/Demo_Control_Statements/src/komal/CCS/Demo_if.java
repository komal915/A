package komal.CCS;

public class Demo_if {

	public static void main(String[] args) {
		int a=2;
		int b=2;
		
		if (a==b) {
			System.out.println("a and b are equal");
		}
	}

}
