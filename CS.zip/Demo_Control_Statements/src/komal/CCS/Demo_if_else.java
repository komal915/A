package komal.CCS;

public class Demo_if_else {

	public static void main(String[] args) {
		int a=2;
		int b=4;
		
		if (a==b) {
			System.out.println("a and b are equal");
		}else {
			System.out.println("a and b are Not equal");
		}
	}

}
