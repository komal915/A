package komal.CCS;

public class Demo_if_else_if {

	public static void main(String[] args) {
		int a = 2;
		int b = 4;

		if (a == b) {
			System.out.println("a and b are equal");
		} else if (a != b) {
			System.out.println("a and b are Not equal");
		} else {
			System.out.println("a and b are Not valid");
		}
	}

}
