package komal.CCS;

public class Demo_nestedif {

	public static void main(String[] args) {
		int a=2;
		int b=2;
		
		if (a==b) { // true
			if (a==b) { // true
				System.out.println("a and b are equal");
			}
		}
	}

}
