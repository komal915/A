
public class Division {

	public static void main(String[] args) {
		System.out.println(1/2);
		System.out.println(3/4);
		System.out.println(5/6);
		System.out.println(6/7);
		System.out.println(7/8);
		// TODO Auto-generated method stub

	}

}
