
public class subtraction {

	public static void main(String[] args) {
		System.out.println(9-8);
		System.out.println(8-7);
		System.out.println(7-6);
		System.out.println(6-5);
		System.out.println(5-4);
		// TODO Auto-generated method stub

	}

}
